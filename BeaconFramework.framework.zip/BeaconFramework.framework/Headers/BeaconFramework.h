//
//  BeaconFramework.h
//  BeaconFramework
//
//  Created by JoeJoe on 2016/2/19.
//  Copyright © 2016年 JoeJoe. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BeaconFramework.
FOUNDATION_EXPORT double BeaconFrameworkVersionNumber;

//! Project version string for BeaconFramework.
FOUNDATION_EXPORT const unsigned char BeaconFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BeaconFramework/PublicHeader.h>


